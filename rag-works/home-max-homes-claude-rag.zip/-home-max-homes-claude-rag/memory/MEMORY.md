# RAG Project Memory

## Project
- Location: `/home/max/homes/claude/rag/`
- Python RAG CLI using Elasticsearch ELSER + OpenRouter
- Python interpreter: `/usr/bin/python3` (3.13) — no `python` or `python3` symlink in PATH

## Stack
- Elasticsearch 8.13.2 with ELSER sparse embedding (`.elser-2-sparse-embedding`)
- OpenRouter (OpenAI-compatible API) for LLM generation
- tiktoken cl100k_base for token counting in chunker

## File Structure
```
rag/
├── requirements.txt   # elasticsearch, openai, python-dotenv, tiktoken
├── .env.example       # template; copy to .env and set OPENROUTER_API_KEY
├── config.py          # load_config() → frozen Config dataclass
├── chunker.py         # chunk_file(path) → list[Chunk]; splits on ## / ### headers
├── indexer.py         # setup(), index_directory(); _build_client() shared factory
├── retriever.py       # retrieve(query, cfg) → list[SearchResult]; imports _build_client
├── generator.py       # generate(question, results, cfg) → str
└── main.py            # CLI: setup | index <dir> | query "<question>"
```

## Key Design Notes
- ELSER vectorization is server-side — no local embedding calls
- `_build_client` lives in indexer.py; retriever.py imports it
- `source_file` stores filename only (not full path)
- Chunker: first splits on `##`/`###` headers, then by blank-line paragraphs if >512 tokens
- Bulk indexing uses `raise_on_error=False` for partial failure tolerance
- `setup` is idempotent: ConflictError for inference endpoint, exists-check for index
- `.env.example` uses `ES_PIPELINE` key (not `ES_INDEX_PIPELINE`)
